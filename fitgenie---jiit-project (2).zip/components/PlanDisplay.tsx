
import React, { useState } from 'react';
import { RecommendationPlan, DailyWorkout, DailyDiet, Meal, ExerciseSlot } from '../types';
import { Activity, Apple, ChevronDown, ChevronUp, Flame, PlayCircle, RefreshCcw, Check, Target, CalendarDays, BarChart3, ChefHat, Dumbbell, ArrowLeft } from 'lucide-react';

interface PlanDisplayProps {
  plan: RecommendationPlan;
  onReset: () => void;
}

const PlanDisplay: React.FC<PlanDisplayProps> = ({ plan, onReset }) => {
  const [activeTab, setActiveTab] = useState<'workout' | 'diet'>('workout');
  const [currentWeek, setCurrentWeek] = useState<number>(0);

  const weekData = plan?.weeks?.[currentWeek];

  if (!weekData) {
    return <div className="text-center p-10 text-slate-500">Loading plan details...</div>;
  }

  const totalWeeks = plan.weeks?.length || 4;
  const progressPercentage = (currentWeek / (totalWeeks - 1)) * 100;
  const stats = plan.stats;

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6 animate-fade-in-up">
      
      {/* Back Button */}
      <div>
        <button 
          onClick={onReset}
          className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 font-bold transition-colors py-2"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Home
        </button>
      </div>

      {/* Summary Header */}
      <div className="bg-white rounded-3xl p-6 md:p-8 shadow-xl border border-slate-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-100 rounded-full blur-3xl opacity-50 -translate-y-1/2 translate-x-1/3"></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="flex-1">
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Your Custom Strategy</h2>
            <p className="text-slate-600 mt-2 text-lg">{plan.summary}</p>
            {plan.projectedTimeline && (
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-50 to-indigo-50 text-indigo-800 px-4 py-2 rounded-xl text-sm font-bold mt-4 border border-indigo-100 shadow-sm">
                 <Target className="w-5 h-5" />
                 Target: {plan.projectedTimeline}
              </div>
            )}
          </div>
          <div className="bg-white px-8 py-5 rounded-2xl shadow-lg border border-slate-100 text-center min-w-[160px]">
            <p className="text-xs text-indigo-500 font-bold uppercase tracking-widest">BMI Score</p>
            <p className="text-4xl font-black text-indigo-600 my-1">{stats?.bmi?.toFixed(1) || "--"}</p>
            <span className="inline-block bg-indigo-100 text-indigo-700 text-xs px-2 py-1 rounded-full font-bold">
              {stats?.bmiCategory || "Calculated"}
            </span>
          </div>
        </div>
      </div>

      {/* Metabolic Analysis Dashboard */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4">
             <div className="w-12 h-12 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center">
               <Flame className="w-6 h-6" />
             </div>
             <div>
               <p className="text-xs font-bold text-slate-400 uppercase">Daily Calorie Target</p>
               <p className="text-2xl font-black text-slate-800">{weekData.dietPlan?.totalCalories || stats.tdee} kcal</p>
               <p className="text-xs text-slate-400">TDEE: {stats.tdee} | BMR: {stats.bmr}</p>
             </div>
          </div>

          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 col-span-2">
             <div className="flex items-center gap-2 mb-3">
               <BarChart3 className="w-5 h-5 text-indigo-600" />
               <h4 className="font-bold text-slate-800">Macro Split Strategy</h4>
             </div>
             <div className="flex flex-col md:flex-row gap-4">
               <div className="flex-1 bg-blue-50 p-3 rounded-xl border border-blue-100">
                 <p className="text-xs font-bold text-blue-400 uppercase">Protein</p>
                 <p className="text-lg font-black text-blue-700">{stats.macros.protein}</p>
               </div>
               <div className="flex-1 bg-green-50 p-3 rounded-xl border border-green-100">
                 <p className="text-xs font-bold text-green-400 uppercase">Carbs</p>
                 <p className="text-lg font-black text-green-700">{stats.macros.carbs}</p>
               </div>
               <div className="flex-1 bg-yellow-50 p-3 rounded-xl border border-yellow-100">
                 <p className="text-xs font-bold text-yellow-500 uppercase">Fats</p>
                 <p className="text-lg font-black text-yellow-700">{stats.macros.fats}</p>
               </div>
             </div>
          </div>
        </div>
      )}

      {/* Week Stepper Progress Indicator */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-6 md:px-10">
        <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="font-bold text-slate-800 text-lg flex items-center gap-2">
                <CalendarDays className="h-5 w-5 text-indigo-600" />
                Your Progression
              </h3>
              <p className="text-slate-400 text-xs font-semibold mt-1 uppercase tracking-wide">
                Current Phase: {weekData.summary}
              </p>
            </div>
            <span className="text-xs font-bold text-white bg-indigo-600 px-3 py-1.5 rounded-full shadow-md shadow-indigo-200">
              Week {currentWeek + 1} of {totalWeeks}
            </span>
        </div>
        
        <div className="relative mx-2 md:mx-6 pb-2 overflow-x-auto">
            <div className="min-w-[300px] py-4">
              <div className="absolute top-1/2 left-0 w-full h-1.5 bg-slate-100 -translate-y-1/2 rounded-full z-0" />
              <div 
                  className="absolute top-1/2 left-0 h-1.5 bg-indigo-600 -translate-y-1/2 rounded-full z-0 transition-all duration-500" 
                  style={{ width: `${progressPercentage}%` }}
              />
              <div className="relative z-10 flex justify-between w-full">
                  {plan.weeks?.map((week, idx) => {
                      const isActive = idx === currentWeek;
                      const isPast = idx < currentWeek;
                      return (
                          <button 
                              key={idx}
                              onClick={() => setCurrentWeek(idx)}
                              className="group flex flex-col items-center focus:outline-none min-w-[40px] relative"
                          >
                              <div className={`
                                  w-10 h-10 md:w-12 md:h-12 rounded-full flex items-center justify-center border-4 transition-all duration-300 bg-white
                                  ${isActive 
                                      ? 'border-indigo-600 text-indigo-600 scale-110 shadow-xl shadow-indigo-100 ring-4 ring-indigo-50' 
                                      : isPast
                                          ? 'border-indigo-600 bg-indigo-600 text-white'
                                          : 'border-slate-200 text-slate-300 hover:border-indigo-300 hover:text-indigo-300'
                                  }
                              `}>
                                  {isPast ? <Check className="w-5 h-5 md:w-6 md:h-6" strokeWidth={3} /> : <span className="text-sm md:text-lg font-bold">{idx + 1}</span>}
                              </div>
                          </button>
                      )
                  })}
              </div>
            </div>
        </div>
      </div>

      {/* Type Tabs */}
      <div className="flex justify-center">
        <div className="bg-slate-100 p-1 rounded-full flex gap-1">
          <button
            onClick={() => setActiveTab('workout')}
            className={`flex items-center gap-2 px-8 py-3 rounded-full font-bold transition-all ${
              activeTab === 'workout'
                ? 'bg-white text-indigo-600 shadow-md transform scale-100'
                : 'text-slate-500 hover:text-indigo-500'
            }`}
          >
            <Activity className="h-5 w-5" /> Workout Plan
          </button>
          <button
            onClick={() => setActiveTab('diet')}
            className={`flex items-center gap-2 px-8 py-3 rounded-full font-bold transition-all ${
              activeTab === 'diet'
                ? 'bg-white text-green-600 shadow-md transform scale-100'
                : 'text-slate-500 hover:text-green-500'
            }`}
          >
            <Apple className="h-5 w-5" /> Diet Plan
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="bg-white rounded-3xl shadow-xl overflow-hidden min-h-[600px] border border-slate-100">
        {activeTab === 'workout' ? (
          <WorkoutView workoutPlan={weekData.workoutPlan || []} />
        ) : (
          <DietView dietPlan={weekData.dietPlan} />
        )}
      </div>

      <div className="text-center pt-8">
        <button 
          onClick={onReset}
          className="text-slate-400 hover:text-indigo-600 font-bold text-sm tracking-widest uppercase transition-colors"
        >
          ← Start Over with New Profile
        </button>
      </div>
    </div>
  );
};

const WorkoutView: React.FC<{ workoutPlan: DailyWorkout[] }> = ({ workoutPlan }) => {
  const [expandedDay, setExpandedDay] = useState<string | null>(workoutPlan?.[0]?.day || null);

  const toggleDay = (day: string) => {
    setExpandedDay(expandedDay === day ? null : day);
  };

  if (!workoutPlan || workoutPlan.length === 0) {
    return <div className="p-12 text-center text-slate-500">No workout plan available for this week.</div>;
  }

  return (
    <div>
      <div className="h-48 w-full relative overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1200&q=80" 
          alt="Workout" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-8">
          <h3 className="text-white text-3xl font-bold">Weekly Routine</h3>
        </div>
      </div>

      <div className="divide-y divide-slate-100">
        {workoutPlan.map((dayPlan, idx) => (
          <div key={idx} className="group">
            <button
              onClick={() => toggleDay(dayPlan.day)}
              className={`w-full text-left px-8 py-6 flex items-center justify-between transition-all ${
                expandedDay === dayPlan.day ? 'bg-indigo-50/50' : 'hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className={`
                   w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg shadow-sm
                   ${expandedDay === dayPlan.day ? 'bg-indigo-600 text-white' : 'bg-white border border-slate-200 text-slate-500'}
                `}>
                  {idx + 1}
                </div>
                <div>
                  <h3 className={`text-xl font-bold ${expandedDay === dayPlan.day ? 'text-indigo-900' : 'text-slate-800'}`}>
                    {dayPlan.day}
                  </h3>
                  <p className="text-sm text-indigo-600 font-semibold">{dayPlan.focus}</p>
                </div>
              </div>
              {expandedDay === dayPlan.day ? (
                <ChevronUp className="text-indigo-500" />
              ) : (
                <ChevronDown className="text-slate-300" />
              )}
            </button>
            
            {expandedDay === dayPlan.day && (
              <div className="px-8 py-8 bg-slate-50/30 space-y-4 animate-fade-in">
                 {dayPlan.exercises?.map((slot, i) => (
                   <ExerciseRow key={i} slot={slot} />
                 ))}
                 {(!dayPlan.exercises || dayPlan.exercises.length === 0) && (
                    <p className="text-sm text-slate-500 italic">Rest day or no exercises listed.</p>
                 )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const ExerciseRow: React.FC<{ slot: ExerciseSlot }> = ({ slot }) => {
  const [showAlternative, setShowAlternative] = useState(false);
  
  const exercise = showAlternative && slot.alternative ? slot.alternative : slot.main;

  return (
    <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow">
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
             <span className="text-[10px] font-extrabold text-indigo-400 uppercase tracking-widest bg-indigo-50 px-2 py-1 rounded-md">{slot.target}</span>
             {showAlternative && <span className="text-[10px] bg-orange-100 text-orange-700 px-2 py-1 rounded-md font-bold uppercase tracking-widest">Alternative</span>}
          </div>
          <h4 className="font-bold text-slate-800 text-lg flex items-center gap-2">
            {exercise.name}
          </h4>
          <p className="text-sm text-slate-500 mt-1 leading-relaxed">{exercise.notes}</p>
        </div>

        <div className="flex items-center gap-4 bg-slate-50 p-3 rounded-xl border border-slate-100 min-w-[140px] justify-center">
            <div className="text-center">
                <div className="text-xl font-black text-slate-800">{exercise.sets}</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase">Sets</div>
            </div>
            <div className="w-px h-8 bg-slate-200"></div>
            <div className="text-center">
                <div className="text-xl font-black text-slate-800">{exercise.reps}</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase">Reps</div>
            </div>
        </div>
      </div>

      <div className="mt-5 flex gap-3">
         <a 
           href={`https://www.youtube.com/results?search_query=how+to+do+${encodeURIComponent(exercise.name)}+exercise`}
           target="_blank"
           rel="noreferrer"
           className="flex-1 flex items-center justify-center gap-2 text-xs font-bold py-2.5 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition"
         >
           <PlayCircle className="h-4 w-4" /> Watch Tutorial
         </a>
         
         {slot.alternative && (
           <button
             onClick={() => setShowAlternative(!showAlternative)}
             className="flex-1 flex items-center justify-center gap-2 text-xs font-bold py-2.5 bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 transition"
           >
             <RefreshCcw className="h-3 w-3" /> {showAlternative ? "Switch to Main" : "Show Alternative"}
           </button>
         )}
      </div>
    </div>
  );
};

const DietView: React.FC<{ dietPlan: DailyDiet }> = ({ dietPlan }) => {
  if (!dietPlan) return <div className="p-8 text-center text-slate-500">No diet plan data.</div>;

  return (
    <div>
      <div className="h-48 w-full relative overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=1200&q=80" 
          alt="Healthy Food" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-8">
          <div className="flex-1">
             <h3 className="text-white text-3xl font-bold">Daily Nutrition</h3>
             <p className="text-white/80 text-sm mt-1">Focus on whole foods and hydration.</p>
          </div>
          <div className="bg-white/20 backdrop-blur-md border border-white/30 text-white px-4 py-2 rounded-xl flex items-center gap-2">
            <Flame className="h-5 w-5 text-orange-400" fill="currentColor" />
            <span className="font-bold text-lg">{dietPlan.totalCalories || 0} kcal</span>
          </div>
        </div>
      </div>

      <div className="p-8">
        <div className="grid gap-8 md:grid-cols-2">
          <MealSlot 
            title="Breakfast" 
            options={dietPlan.breakfast || []} 
            color="orange" 
            image="https://images.unsplash.com/photo-1493770348161-369560ae357d?w=600&q=80"
          />
          <MealSlot 
            title="Lunch" 
            options={dietPlan.lunch || []} 
            color="green"
            image="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&q=80"
          />
          <MealSlot 
            title="Snack" 
            options={dietPlan.snack || []} 
            color="purple"
            image="https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea?w=600&q=80"
          />
          <MealSlot 
            title="Dinner" 
            options={dietPlan.dinner || []} 
            color="blue"
            image="https://images.unsplash.com/photo-1594998893017-3614795c3e45?w=600&q=80"
          />
        </div>
        
        <div className="mt-10 p-4 bg-blue-50 border border-blue-100 rounded-xl text-center">
            <p className="text-xs text-blue-800 font-medium">
                💧 <span className="font-bold">Hydration Reminder:</span> Drink at least 3-4 liters of water throughout the day to support your metabolic rate.
            </p>
        </div>
      </div>
    </div>
  );
};

const MealSlot: React.FC<{ title: string, options: Meal[], color: string, image: string }> = ({ title, options, color, image }) => {
    const [selectedOption, setSelectedOption] = useState(0);
    const meal = options?.[selectedOption] || options?.[0];

    if (!meal) return null;

    return (
        <div className={`rounded-2xl border bg-white shadow-sm overflow-hidden flex flex-col h-full hover:shadow-md transition-all`}>
            <div className="h-32 relative overflow-hidden">
                <img src={image} alt={title} className="w-full h-full object-cover transition-transform hover:scale-105 duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                     <h4 className="font-bold text-white uppercase tracking-wider text-sm">{title}</h4>
                </div>
                {options.length > 1 && (
                    <div className="absolute top-3 right-3 flex bg-black/40 backdrop-blur-md rounded-lg p-1 gap-1">
                        {options.map((_, idx) => (
                            <button
                                key={idx}
                                onClick={() => setSelectedOption(idx)}
                                className={`text-[10px] font-bold w-6 h-6 rounded flex items-center justify-center transition-all ${
                                    selectedOption === idx ? 'bg-white text-black' : 'text-white hover:bg-white/20'
                                }`}
                            >
                                {idx + 1}
                            </button>
                        ))}
                    </div>
                )}
            </div>

            <div className="p-5 flex-grow flex flex-col">
                <MealContent meal={meal} color={color} />
            </div>
        </div>
    );
}

const MealContent: React.FC<{ meal: Meal, color: string }> = ({ meal, color }) => {
    const [showRecipe, setShowRecipe] = useState(false);

    return (
        <div className="flex-grow flex flex-col">
            <h3 className="text-lg font-bold mb-2 text-slate-800">{meal.name}</h3>
            <p className="text-sm text-slate-500 mb-4 flex-grow">{meal.description}</p>
            
            <div className="flex flex-wrap gap-2 text-xs font-bold mb-4">
                <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md">{meal.calories} kcal</span>
                <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md">{meal.protein} protein</span>
            </div>

            {meal.recipe && (
                <div className="mt-auto pt-3 border-t border-slate-100">
                    <button 
                        onClick={() => setShowRecipe(!showRecipe)}
                        className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors w-full justify-center py-1"
                    >
                        <ChefHat className="h-4 w-4" /> {showRecipe ? 'Close Recipe' : 'View Recipe'}
                    </button>
                    
                    {showRecipe && (
                        <div className="mt-3 p-3 bg-slate-50 rounded-lg text-sm text-slate-600 animate-fade-in border border-slate-100">
                            <span className="block font-bold mb-1 text-xs uppercase text-slate-400">Preparation</span>
                            {meal.recipe}
                            <a 
                                href={`https://www.youtube.com/results?search_query=how+to+cook+${encodeURIComponent(meal.name)}+recipe`}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center gap-1 mt-3 text-red-600 hover:text-red-700 text-xs font-bold"
                            >
                                <PlayCircle className="w-3 h-3" /> Watch Cooking Video
                            </a>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

export default PlanDisplay;
