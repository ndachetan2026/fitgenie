
import React, { useState } from 'react';
import { FitnessGoal, DietaryPreference, Gender, UserProfile, ActivityLevel, Sport } from '../types';
import { Dumbbell, Utensils, Ruler, Weight, User, ArrowRight, Calendar, Activity, Trophy, Zap, Target } from 'lucide-react';

interface InputFormProps {
  onSubmit: (profile: UserProfile) => void;
  isLoading: boolean;
}

const InputForm: React.FC<InputFormProps> = ({ onSubmit, isLoading }) => {
  const [profile, setProfile] = useState<UserProfile>({
    age: 20,
    weight: 65,
    height: 170,
    gender: Gender.MALE,
    goal: FitnessGoal.FAT_LOSS,
    activityLevel: ActivityLevel.MODERATELY_ACTIVE,
    dietPreference: DietaryPreference.VEGETARIAN,
    planDuration: "4",
    workoutDays: 4,
    sport: Sport.NONE
  });

  const handleChange = (field: keyof UserProfile, value: any) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(profile);
  };

  return (
    <div className="w-full max-w-4xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100">
      <div className="relative h-56 bg-indigo-600 overflow-hidden">
         <img 
           src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1200&q=80" 
           alt="Gym background" 
           className="w-full h-full object-cover opacity-20"
         />
         <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-6 text-center">
            <h2 className="text-3xl font-bold flex items-center gap-2">
              <User className="h-8 w-8" />
              Build Your Profile
            </h2>
            <p className="opacity-90 mt-2 max-w-lg">Tell us about your goals, stats, and lifestyle. Our AI will craft a precision plan just for you.</p>
         </div>
      </div>

      <form onSubmit={handleSubmit} className="p-8 space-y-8">
        
        {/* Basic Stats Grid */}
        <section>
          <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-sm">1</div>
            Your Stats
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">Age</label>
              <input
                type="number"
                value={profile.age}
                onChange={(e) => handleChange('age', parseInt(e.target.value))}
                className="w-full pl-3 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                required
              />
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700 flex items-center gap-1">
                <Weight className="h-4 w-4 text-slate-400" /> Current Weight (kg)
              </label>
              <input
                type="number"
                value={profile.weight}
                onChange={(e) => handleChange('weight', parseInt(e.target.value))}
                className="w-full pl-3 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                required
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700 flex items-center gap-1">
                <Ruler className="h-4 w-4 text-slate-400" /> Height (cm)
              </label>
              <input
                type="number"
                value={profile.height}
                onChange={(e) => handleChange('height', parseInt(e.target.value))}
                className="w-full pl-3 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                required
              />
            </div>
          </div>

          {/* Gender */}
          <div className="mt-6">
            <label className="block text-sm font-medium text-slate-700 mb-2">Gender</label>
            <div className="flex gap-4">
              {Object.values(Gender).map((g) => (
                <label key={g} className={`
                  flex-1 border rounded-lg p-3 cursor-pointer text-center transition-all
                  ${profile.gender === g ? 'bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500' : 'hover:bg-slate-50 border-slate-200'}
                `}>
                  <input
                    type="radio"
                    name="gender"
                    value={g}
                    checked={profile.gender === g}
                    onChange={() => handleChange('gender', g)}
                    className="sr-only"
                  />
                  {g}
                </label>
              ))}
            </div>
          </div>
        </section>

        <hr className="border-slate-100" />

        {/* Goals & Lifestyle */}
        <section>
          <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
             <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-sm">2</div>
             Goals & Lifestyle
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700 flex items-center gap-1">
                  <Dumbbell className="h-4 w-4 text-slate-400" /> Fitness Goal
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {Object.values(FitnessGoal).map((goal) => (
                    <label key={goal} className={`
                      border rounded-lg p-3 cursor-pointer transition-all flex items-center
                      ${profile.goal === goal ? 'bg-indigo-50 border-indigo-500 text-indigo-700 ring-1 ring-indigo-500' : 'hover:bg-slate-50 border-slate-200'}
                    `}>
                      <input
                        type="radio"
                        name="goal"
                        value={goal}
                        checked={profile.goal === goal}
                        onChange={() => handleChange('goal', goal)}
                        className="sr-only"
                      />
                      <span className="font-medium">{goal}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Conditional Target Weight Input */}
              {(profile.goal === FitnessGoal.FAT_LOSS || profile.goal === FitnessGoal.MUSCLE_GAIN) && (
                <div className="space-y-2 animate-fade-in bg-orange-50 p-4 rounded-xl border border-orange-100">
                  <label className="block text-sm font-bold text-orange-800 flex items-center gap-1">
                    <Target className="h-4 w-4" /> Target Weight (kg)
                  </label>
                  <input
                    type="number"
                    value={profile.targetWeight || ''}
                    placeholder={`Aiming for...`}
                    onChange={(e) => handleChange('targetWeight', parseInt(e.target.value))}
                    className="w-full pl-3 pr-4 py-3 border border-orange-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none text-orange-900 font-bold bg-white"
                  />
                  <p className="text-xs text-orange-600">Enter your goal weight for better timeline prediction.</p>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700 flex items-center gap-1">
                  <Zap className="h-4 w-4 text-slate-400" /> Current Activity Level
                </label>
                <select 
                  value={profile.activityLevel}
                  onChange={(e) => handleChange('activityLevel', e.target.value)}
                  className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  {Object.values(ActivityLevel).map((level) => (
                    <option key={level} value={level}>{level}</option>
                  ))}
                </select>
              </div>

              {profile.goal === FitnessGoal.ATHLETE && (
                 <div className="space-y-2 animate-fade-in">
                    <label className="block text-sm font-bold text-indigo-700 flex items-center gap-1">
                      <Trophy className="h-4 w-4" /> Select Your Sport
                    </label>
                    <select 
                      value={profile.sport}
                      onChange={(e) => handleChange('sport', e.target.value)}
                      className="w-full p-3 border-2 border-indigo-100 bg-indigo-50 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-indigo-900 font-medium"
                    >
                      {Object.values(Sport).filter(s => s !== Sport.NONE).map((sport) => (
                        <option key={sport} value={sport}>{sport}</option>
                      ))}
                    </select>
                 </div>
              )}

              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700 flex items-center gap-1">
                  <Utensils className="h-4 w-4 text-slate-400" /> Dietary Preference
                </label>
                <div className="flex flex-wrap gap-2">
                  {Object.values(DietaryPreference).map((diet) => (
                    <label key={diet} className={`
                      flex-1 min-w-[120px] border rounded-lg p-2 cursor-pointer transition-all text-center text-sm
                      ${profile.dietPreference === diet ? 'bg-green-50 border-green-500 text-green-700 ring-1 ring-green-500' : 'hover:bg-slate-50 border-slate-200'}
                    `}>
                      <input
                        type="radio"
                        name="diet"
                        value={diet}
                        checked={profile.dietPreference === diet}
                        onChange={() => handleChange('dietPreference', diet)}
                        className="sr-only"
                      />
                      <span className="font-medium">{diet}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        <hr className="border-slate-100" />

        {/* Schedule */}
        <section>
          <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
             <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-sm">3</div>
             Schedule & Duration
          </h3>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700 flex items-center gap-1">
                <Activity className="h-4 w-4 text-slate-400" /> Workout Days per Week
              </label>
              <div className="flex justify-between gap-2">
                {[3, 4, 5, 6].map((days) => (
                  <label key={days} className={`
                    flex-1 border rounded-lg p-3 cursor-pointer transition-all flex flex-col items-center justify-center
                    ${profile.workoutDays === days ? 'bg-purple-50 border-purple-500 text-purple-700 ring-1 ring-purple-500' : 'hover:bg-slate-50 border-slate-200'}
                  `}>
                    <input
                      type="radio"
                      name="workoutDays"
                      value={days}
                      checked={profile.workoutDays === days}
                      onChange={() => handleChange('workoutDays', days)}
                      className="sr-only"
                    />
                    <span className="font-bold text-xl">{days}</span>
                    <span className="text-[10px] uppercase font-bold text-slate-400">Days</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700 flex items-center gap-1">
                <Calendar className="h-4 w-4 text-slate-400" /> Plan Duration
              </label>
              <div className="flex justify-between gap-2">
                {[
                  { label: '4 Weeks', value: "4" },
                  { label: '8 Weeks', value: "8" },
                  { label: '12 Weeks', value: "12" }
                ].map((option) => (
                  <label key={option.value} className={`
                    flex-1 border rounded-lg p-3 cursor-pointer transition-all flex flex-col items-center justify-center
                    ${profile.planDuration === option.value ? 'bg-purple-50 border-purple-500 text-purple-700 ring-1 ring-purple-500' : 'hover:bg-slate-50 border-slate-200'}
                  `}>
                    <input
                      type="radio"
                      name="duration"
                      value={option.value}
                      checked={profile.planDuration === option.value}
                      onChange={() => handleChange('planDuration', option.value)}
                      className="sr-only"
                    />
                    <span className="font-bold text-xl">{option.value}</span>
                    <span className="text-[10px] uppercase font-bold text-slate-400">Weeks</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </section>

        <button
          type="submit"
          disabled={isLoading}
          className={`
            w-full py-5 rounded-xl text-white font-bold text-lg shadow-lg flex items-center justify-center gap-2 transition-all mt-6
            ${isLoading ? 'bg-slate-400 cursor-not-allowed' : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 hover:shadow-xl transform hover:-translate-y-0.5'}
          `}
        >
          {isLoading ? (
            <>AI Coach is Analyzing...</>
          ) : (
            <>Generate My Personalized Plan <ArrowRight className="h-5 w-5" /></>
          )}
        </button>
      </form>
    </div>
  );
};

export default InputForm;
