import React from 'react';
import { Sparkles, Download, FileText } from 'lucide-react';

const Header: React.FC = () => {
  const handleDownload = () => {
     alert("Downloading Project Synopsis (CHETAN SYNOPSIS.pdf)...");
     // In a real backend scenario, this would trigger a file download from the server
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-lg transform rotate-3">
            <Sparkles className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-slate-800 tracking-tight">FitGenIE</h1>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest -mt-1">JIIT Minor Project</p>
          </div>
        </div>
        <nav className="flex items-center gap-6 text-sm font-medium text-slate-500">
          <button 
             onClick={handleDownload}
             className="hidden md:flex items-center gap-2 text-indigo-600 bg-indigo-50 px-4 py-2 rounded-lg hover:bg-indigo-100 transition font-bold"
          >
            <Download className="h-4 w-4" /> Download Synopsis
          </button>
        </nav>
      </div>
    </header>
  );
};

export default Header;