
export enum FitnessGoal {
  FAT_LOSS = 'Fat Loss',
  MUSCLE_GAIN = 'Muscle Gain',
  ENDURANCE = 'Endurance',
  GENERAL_FITNESS = 'General Fitness',
  ATHLETE = 'Athlete Training'
}

export enum DietaryPreference {
  VEGETARIAN = 'Vegetarian',
  EGGETARIAN = 'Eggetarian',
  NON_VEGETARIAN = 'Non-Vegetarian',
  VEGAN = 'Vegan'
}

export enum Gender {
  MALE = 'Male',
  FEMALE = 'Female',
  OTHER = 'Other'
}

export enum ActivityLevel {
  SEDENTARY = 'Sedentary (Little to no exercise)',
  LIGHTLY_ACTIVE = 'Lightly Active (1-3 days/week)',
  MODERATELY_ACTIVE = 'Moderately Active (3-5 days/week)',
  VERY_ACTIVE = 'Very Active (6-7 days/week)',
  EXTRA_ACTIVE = 'Extra Active (Physical job or 2x training)'
}

export enum Sport {
  NONE = 'None',
  BASKETBALL = 'Basketball',
  FOOTBALL = 'Football',
  CRICKET = 'Cricket',
  TENNIS = 'Tennis',
  RUNNING = 'Running',
  BADMINTON = 'Badminton',
  BOXING = 'Boxing',
  SWIMMING = 'Swimming'
}

export interface UserProfile {
  age: number;
  weight: number; // in kg
  targetWeight?: number; // Optional target in kg
  height: number; // in cm
  gender: Gender;
  goal: FitnessGoal;
  sport?: Sport; // Optional, only if goal is ATHLETE
  activityLevel: ActivityLevel;
  dietPreference: DietaryPreference;
  planDuration: string; // "4", "8", or "12" weeks
  workoutDays: number; // 3, 4, 5, 6
}

export interface Meal {
  name: string;
  description: string;
  calories: number;
  protein: string;
  recipe: string; // Instructions
}

export interface DailyDiet {
  breakfast: Meal[]; // Array of options (min 2)
  lunch: Meal[];
  snack: Meal[];
  dinner: Meal[];
  totalCalories: number;
}

export interface Exercise {
  name: string;
  sets: string;
  reps: string;
  notes: string;
}

export interface ExerciseSlot {
  target: string;
  main: Exercise;
  alternative: Exercise;
}

export interface DailyWorkout {
  day: string;
  focus: string;
  exercises: ExerciseSlot[];
}

export interface WeeklyPlan {
  weekNumber: number;
  summary: string; // Focus for this week (e.g., "Conditioning Phase")
  dietPlan: DailyDiet; // Representative day for this week
  workoutPlan: DailyWorkout[];
}

export interface Macros {
  protein: string;
  carbs: string;
  fats: string;
}

export interface MetabolicStats {
  bmr: number;
  tdee: number;
  bmi: number;
  bmiCategory: string;
  macros: Macros;
}

export interface RecommendationPlan {
  weeks: WeeklyPlan[]; // Array of weeks based on duration
  stats: MetabolicStats;
  summary: string; // Overall strategy
  projectedTimeline: string; // e.g. "Based on your goal of losing 5kg..."
}
