import React, { useState } from 'react';
import Header from './components/Header';
import InputForm from './components/InputForm';
import PlanDisplay from './components/PlanDisplay';
import { UserProfile, RecommendationPlan } from './types';
import { generatePlan } from './services/geminiService';
import { Loader2 } from 'lucide-react';

function App() {
  const [plan, setPlan] = useState<RecommendationPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFormSubmit = async (profile: UserProfile) => {
    setLoading(true);
    setError(null);
    try {
      const generatedPlan = await generatePlan(profile);
      setPlan(generatedPlan);
    } catch (err) {
      setError("Failed to generate plan. Please try again or check your API key.");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setPlan(null);
    setError(null);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Header />

      <main className="flex-grow container mx-auto px-4 py-8 md:py-12">
        {error && (
          <div className="max-w-2xl mx-auto mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 flex items-center justify-between">
            <p>{error}</p>
            <button onClick={() => setError(null)} className="text-sm font-bold underline">Dismiss</button>
          </div>
        )}

        {!plan && !loading && (
          <div className="flex flex-col items-center justify-center animate-fade-in">
             <div className="text-center mb-10 max-w-3xl">
                <h1 className="text-4xl md:text-6xl font-black text-slate-900 mb-6 leading-tight tracking-tight">
                  AI-Powered <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-500">Performance</span> Coaching
                </h1>
                <p className="text-lg md:text-xl text-slate-600 max-w-2xl mx-auto">
                  Get a comprehensive workout roadmap, metabolic analysis, and athlete-specific training—designed instantly by AI.
                </p>
             </div>
            <InputForm onSubmit={handleFormSubmit} isLoading={loading} />
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center justify-center h-[60vh] text-center">
            <Loader2 className="h-16 w-16 text-indigo-600 animate-spin mb-6" />
            <h3 className="text-2xl font-bold text-slate-800 mb-2">Analyzing Metabolism & Goals...</h3>
            <p className="text-slate-500 max-w-md">
              Our AI is calculating your TDEE, designing sport-specific drills, and structuring your progressive overload plan.
            </p>
          </div>
        )}

        {plan && !loading && (
          <PlanDisplay plan={plan} onReset={handleReset} />
        )}
      </main>

      <footer className="bg-white border-t border-slate-200 py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-400 text-sm">
          <p className="mb-2 font-semibold">JIIT Sector-62, Noida - Minor Project Synopsis Implementation</p>
          <p>© {new Date().getFullYear()} FitGenIE. Powered by Google Gemini AI.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;