
import { GoogleGenAI, Type, Schema } from "@google/genai";
import { UserProfile, RecommendationPlan, FitnessGoal, DietaryPreference } from "../types";

const generatePrompt = (user: UserProfile) => {
  const isAthlete = user.goal === FitnessGoal.ATHLETE;
  const sportContext = isAthlete ? `SPORT: ${user.sport}. Include sport-specific drills (agility, plyometrics, conditioning) relevant to ${user.sport}.` : "";
  const targetWeightContext = user.targetWeight ? `TARGET WEIGHT: ${user.targetWeight}kg. Calculate timeline to reach this from ${user.weight}kg.` : "";
  
  // Speed optimization instruction: Limit phases to 4 max.
  const durationContext = `
    DURATION: ${user.planDuration} Weeks. 
    IMPORTANT: To ensure a fast response, generate exactly 4 distinct 'Weeks' representing 4 PHASES of the plan (e.g., Phase 1, Phase 2, Phase 3, Phase 4) that cover the entire ${user.planDuration} weeks.
  `;

  const dietContext = user.dietPreference === DietaryPreference.VEGETARIAN 
    ? "DIET NOTE: User is Indian Vegetarian. REQUIRED: Aggressively prioritize high-protein sources (Soya chunks, Paneer, Lentils/Dals, Chickpeas, Greek Yogurt, Whey Protein) in every meal to ensure adequate protein intake." 
    : `Diet: ${user.dietPreference} (Indian context preferred).`;

  return `
    Act as a world-class AI Fitness Coach and Nutritionist.
    Create a highly personalized progressive workout and diet plan.

    Profile:
    - Age: ${user.age}, Gender: ${user.gender}
    - Stats: ${user.weight}kg, ${user.height}cm
    - ${targetWeightContext}
    - Activity Level: ${user.activityLevel}
    - Goal: ${user.goal}
    - ${sportContext}
    - ${dietContext}
    - Workout Schedule: ${user.workoutDays} days/week.
    - ${durationContext}

    **CRITICAL CALCULATIONS**:
    1. Calculate **BMI**.
    2. Calculate **BMR** (Mifflin-St Jeor Equation).
    3. Calculate **TDEE** based on Activity Level.
    4. Set **Target Calories** based on Goal (e.g., -500 for loss, +300 for gain).
    5. Define **Macros** (Protein/Carbs/Fats) split in grams/percentages.

    **PLAN REQUIREMENTS**:
    1. **Timeline**: Estimate specific weeks to reach goal in 'projectedTimeline'.
    2. **Progression**: The plan MUST evolve. Phase 1 (Foundation) -> Phase 4 (Peak).
    3. **Structure**: Return an array of exactly 4 items (Weeks/Phases).
    4. **Diet**: For EACH meal slot, provide 2 DISTINCT OPTIONS. Keep recipes concise.
    5. **Workout**: Exactly ${user.workoutDays} workout days per week.
       - If Athlete: Include specific drills for ${user.sport}.
       - Include 'Main' and 'Alternative' exercises.
    6. **Speed**: Keep exercise notes and recipe instructions SHORT and CONCISE to generate faster.
    7. **Format**: Return ONLY JSON matching the schema.
  `;
};

const exerciseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING },
    sets: { type: Type.STRING },
    reps: { type: Type.STRING },
    notes: { type: Type.STRING }
  },
  required: ["name", "sets", "reps"]
};

const mealSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING },
    description: { type: Type.STRING },
    calories: { type: Type.NUMBER },
    protein: { type: Type.STRING },
    recipe: { type: Type.STRING, description: "Very short instructions (max 20 words)" }
  },
  required: ["name", "description", "calories", "protein", "recipe"]
};

const statsSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    bmr: { type: Type.NUMBER, description: "Basal Metabolic Rate" },
    tdee: { type: Type.NUMBER, description: "Total Daily Energy Expenditure" },
    bmi: { type: Type.NUMBER },
    bmiCategory: { type: Type.STRING },
    macros: {
      type: Type.OBJECT,
      properties: {
        protein: { type: Type.STRING, description: "e.g. '150g (30%)'" },
        carbs: { type: Type.STRING, description: "e.g. '200g (40%)'" },
        fats: { type: Type.STRING, description: "e.g. '70g (30%)'" }
      },
      required: ["protein", "carbs", "fats"]
    }
  },
  required: ["bmr", "tdee", "bmi", "bmiCategory", "macros"]
};

const planSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    stats: statsSchema,
    summary: { type: Type.STRING },
    projectedTimeline: { type: Type.STRING, description: "Estimated time to reach final goal" },
    weeks: {
      type: Type.ARRAY,
      description: "4 Progressive Phases",
      items: {
        type: Type.OBJECT,
        properties: {
          weekNumber: { type: Type.NUMBER },
          summary: { type: Type.STRING, description: "Phase Focus (e.g. 'Weeks 1-3: Foundation')" },
          dietPlan: {
            type: Type.OBJECT,
            properties: {
              breakfast: { type: Type.ARRAY, items: mealSchema, description: "2 Options" },
              lunch: { type: Type.ARRAY, items: mealSchema, description: "2 Options" },
              snack: { type: Type.ARRAY, items: mealSchema, description: "2 Options" },
              dinner: { type: Type.ARRAY, items: mealSchema, description: "2 Options" },
              totalCalories: { type: Type.NUMBER }
            },
            required: ["breakfast", "lunch", "snack", "dinner", "totalCalories"]
          },
          workoutPlan: {
            type: Type.ARRAY,
            description: "List of workout days",
            items: {
              type: Type.OBJECT,
              properties: {
                day: { type: Type.STRING },
                focus: { type: Type.STRING },
                exercises: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      target: { type: Type.STRING },
                      main: exerciseSchema,
                      alternative: exerciseSchema
                    },
                    required: ["target", "main", "alternative"]
                  }
                }
              },
              required: ["day", "focus", "exercises"]
            }
          }
        },
        required: ["weekNumber", "summary", "dietPlan", "workoutPlan"]
      }
    }
  },
  required: ["stats", "summary", "projectedTimeline", "weeks"]
};

export const generatePlan = async (user: UserProfile): Promise<RecommendationPlan> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: generatePrompt(user),
      config: {
        responseMimeType: 'application/json',
        responseSchema: planSchema,
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as RecommendationPlan;
  } catch (error) {
    console.error("Error generating plan:", error);
    throw error;
  }
};
